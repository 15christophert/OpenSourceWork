#################################################################
##           Practical 6 for GEOM184 - Open Source GIS         ##
##                      14/11/2025                             ##
##                  Creating a ShinyApp                        ##
##                        Global.R                             ##
##        code by Diego Panici (d.panici@exeter.ac.uk)         ##
#################################################################


# Load and repair large wood, river, and bridge data ----
lw_points <- st_read("LW.shp")
river <- st_read("Torridge_Buffer_Taper.shp")
river <- st_union(river)
river<- st_sf(geometry = st_sfc(river))
bridges <- st_read("Torridge_Bridges_Clip.shp")
bridges <- bridges[!st_is_empty(bridges$geometry), ]

# Load  clusters, distances and LW retention structures
clusters <- st_read("LW_Cluster.shp")
distances <- st_read("LW_Distances.shp")
catchers <- st_read("LW_Retention_Structures.shp")

# Convert vectors to CRS 4326
lw_points <- st_transform(lw_points, crs = 4326)
river <- st_transform(river, crs = 4326)
bridges <- st_transform(bridges, crs = 4326)
clusters <- st_transform(clusters, crs = 4326)
distances <- st_transform(distances, crs = 4326)
catchers <- st_transform(catchers, crs = 4326)

# Load star icon ----
star_icon <- makeIcon(
  iconUrl = file.path(getwd(), "star_icon.png"),
  iconWidth = 30,
  iconHeight = 30
)

# Load and project raster layers
heatmap <- rast("LW_Heatmap_V3.tif")
aspect <- rast("aspect_clip.tif")
slope <- rast("slope_clip.tif")

heatmap <- project(heatmap, crs(river))
aspect <- project(aspect, crs(river))
slope <- project(slope, crs(river))

# Generate colours for LW points and catchers
pal_LW_points <- colorFactor(palette =c("red", "orange", "green"), domain = lw_points$LW_Type)

# Dynamically generate colours based on number of unique clusters
num_clusters <- length(unique(clusters$CLUSTER_ID))
pal_clusters <- colorFactor(palette = colorRampPalette(brewer.pal(12, "Paired"))(num_clusters), domain = clusters$CLUSTER_ID)

# Generate colours based on distance from bridge
pal_distances <- colorBin(palette = "RdBu", domain = distances$Distance_5, bins = 5, pretty = TRUE)

# Generate colours for rasters
pal_heatmap <- colorNumeric(palette = "inferno", domain = na.omit(values(heatmap)), na.color = "transparent")
pal_aspect <- colorNumeric(palette = "inferno", domain = na.omit(values(aspect)), na.color = "transparent")
pal_slope <- colorNumeric(palette = "inferno", domain = na.omit(values(slope)), na.color = "transparent")
